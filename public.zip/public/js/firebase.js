let firebaseConfig = {
    // Enter your firebase credentials
};

firebase.initializeApp(firebaseConfig);

let db = firebase.firestore();